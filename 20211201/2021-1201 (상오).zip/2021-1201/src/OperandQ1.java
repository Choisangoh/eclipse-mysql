
public class OperandQ1 {

	public static void main(String[] args) {
		// 다음 조건을 만족하는 코드를 작성해주세요.
		// kor, math, eng, com 변수를 한 줄로 선언하고, 각각
		// 80,  55,    65,  85 를 대입해주시고,
		// total 변수에 총점을 저장하고,
		// 콘솔창에 평균 점수를 출력해주세요.

	String("kor,math,eng,com"); 
	}

}
