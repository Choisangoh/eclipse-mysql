
public class Databool36P {

public static void main(String[] args) {
	// boolean 자료형은 참 거짓 구분할 때 씀
	// 이 자료형의 변수에는 오직 true/false만 가능
	
	boolean a = true;
	boolean b = false;
	System.out.println(a);
	System.out.println(b);
	
	
	
	
	
}
	}

